# TroveExtract
提取Trove全部的资源文件。
# 使用方法
将`TroveExtract.bat`文件放入游戏目录，运行该文件。  
资源文件将被提取到游戏目录的`extracted`文件夹。
